import { CartErrorEvent, CartLinesUpdateEvent } from '@shopify/events';

const MARKER_KEYS = ['_theme_upsell_key', '_theme_gift_key', '_theme_additional_key'];

function sectionIds() {
  const ids = new Set();
  document.querySelectorAll('cart-items-component[data-section-id]').forEach((component) => {
    if (component.dataset.sectionId) ids.add(component.dataset.sectionId);
  });
  return [...ids];
}

function cartUrl() {
  return window.Theme?.routes?.cart_url || '/cart';
}

async function getCart() {
  const response = await fetch(`${cartUrl().replace(/\/$/, '')}.js`, {
    headers: { Accept: 'application/json' },
    credentials: 'same-origin',
  });
  if (!response.ok) throw new Error(`Unable to refresh cart (${response.status}).`);
  return response.json();
}

function hasMarker(item, key, value) {
  return String(item?.properties?.[key] || '') === String(value);
}

function isDecorative(item) {
  return MARKER_KEYS.some((key) => item?.properties?.[key]);
}

function formatMoney(cents) {
  if (window.Shopify?.formatMoney) return window.Shopify.formatMoney(cents);
  return new Intl.NumberFormat(document.documentElement.lang || undefined, {
    style: 'currency',
    currency: window.Shopify?.currency?.active || 'USD',
  }).format(cents / 100);
}

async function mutateCart(element, { url, body, action, lines, source }) {
  const promise = CartLinesUpdateEvent.createPromise();
  document.dispatchEvent(
    new CartLinesUpdateEvent({
      action,
      context: 'cart',
      lines,
      promise: promise.promise,
    })
  );

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok || result.status || result.errors) {
      throw new Error(result.description || result.message || result.errors || '购物车更新失败。');
    }

    const cart = result.items ? result : await getCart();
    promise.resolve({
      cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
      detail: {
        items: cart.items,
        sections: result.sections,
        didError: false,
        source,
      },
    });
    return cart;
  } catch (error) {
    promise.resolve({ detail: { didError: true, source } });
    document.dispatchEvent(
      new CartErrorEvent({ error: error?.message || '购物车更新失败。', code: 'INVALID' })
    );
    throw error;
  }
}

class CartGift extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;
    this.dataset.runtimeBound = 'true';
    this.abortController = new AbortController();
    this.syncing = false;
    this.#sync();
  }

  disconnectedCallback() {
    this.abortController?.abort();
    this.abortController = null;
    delete this.dataset.runtimeBound;
  }

  async #sync() {
    if (this.syncing) return;
    this.syncing = true;
    try {
      const cart = await getCart();
      const items = Array.isArray(cart.items) ? cart.items : [];
      const primaryItems = items.filter((item) => !isDecorative(item));
      const type = this.dataset.goalType || 'subtotal';
      const basis = type === 'quantity'
        ? primaryItems.reduce((total, item) => total + Number(item.quantity || 0), 0)
        : primaryItems.reduce((total, item) => total + Number(item.final_line_price || 0), 0);
      const requirement = Number(this.dataset.requirement || 0);
      const variantId = String(this.dataset.variantId || '');
      const available = this.dataset.variantAvailable !== 'false';
      const giftKey = this.dataset.giftKey || '';
      const giftItems = items.filter((item) => hasMarker(item, '_theme_gift_key', giftKey));
      const currentGift = giftItems[0];
      const unlocked = primaryItems.length > 0 && available && basis >= requirement;
      this.dataset.unlocked = String(unlocked);
      this.#updateMessage(unlocked, Math.max(requirement - basis, 0), type);

      if (this.dataset.designMode === 'true' || !variantId || !giftKey) return;
      if (unlocked && (!currentGift || String(currentGift.variant_id) !== variantId)) {
        for (const item of giftItems) {
          await this.#remove(item);
        }
        await this.#add(variantId, giftKey);
      } else if (!unlocked) {
        for (const item of giftItems) {
          await this.#remove(item);
        }
      }
    } catch (error) {
      if (error?.name !== 'AbortError') console.warn('[cart-gift] Unable to sync gift:', error);
    } finally {
      this.syncing = false;
    }
  }

  #updateMessage(unlocked, remaining, type) {
    const message = this.querySelector('[data-gift-message]');
    if (!message) return;
    const template = unlocked ? this.dataset.unlockedText : this.dataset.lockedText;
    if (!template) return;
    const amount = type === 'quantity' ? String(Math.round(remaining)) : formatMoney(remaining);
    message.textContent = template.replace('[amount]', amount);
  }

  async #add(variantId, giftKey) {
    const ids = sectionIds();
    const body = {
      items: [{ id: Number(variantId), quantity: 1, properties: { _theme_gift_key: giftKey } }],
      sections: ids.join(','),
      sections_url: window.location.pathname,
    };
    await mutateCart(this, {
      url: window.Theme?.routes?.cart_add_url || '/cart/add.js',
      body,
      action: 'add',
      lines: [{ merchandiseId: variantId, quantity: 1 }],
      source: 'cart-gift',
    });
  }

  async #remove(item) {
    const ids = sectionIds();
    const body = {
      id: item.key,
      quantity: 0,
      sections: ids.join(','),
      sections_url: window.location.pathname,
    };
    await mutateCart(this, {
      url: window.Theme?.routes?.cart_change_url || '/cart/change.js',
      body,
      action: 'remove',
      lines: [{ id: item.key, quantity: 0 }],
      source: 'cart-gift',
    });
  }
}

class CartUpsells extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;
    this.dataset.runtimeBound = 'true';
    this.abortController = new AbortController();
    const { signal } = this.abortController;
    this.addEventListener('change', this.#onChange, { signal });
    this.addEventListener('click', this.#onClick, { signal });
    this.#syncState();
  }

  disconnectedCallback() {
    this.abortController?.abort();
    this.abortController = null;
    delete this.dataset.runtimeBound;
  }

  async #onChange(event) {
    const select = event.target.closest('[data-upsell-variant]');
    if (!(select instanceof HTMLSelectElement)) return;
    const item = select.closest('[data-upsell-item]');
    const option = select.options[select.selectedIndex];
    if (!item || !option) return;
    item.dataset.variantId = option.value;
    item.dataset.variantAvailable = option.dataset.available !== 'false' ? 'true' : 'false';
    const price = item.querySelector('[data-upsell-price]');
    if (price && option.dataset.price) price.textContent = formatMoney(Number(option.dataset.price));
    await this.#syncState();
  }

  async #onClick(event) {
    const button = event.target.closest('[data-upsell-action]');
    if (!(button instanceof HTMLButtonElement)) return;
    const item = button.closest('[data-upsell-item]');
    if (!(item instanceof HTMLElement) || item.dataset.busy === 'true') return;
    event.preventDefault();
    item.dataset.busy = 'true';
    button.disabled = true;
    try {
      const cart = await getCart();
      const key = item.dataset.upsellKey || '';
      const existing = cart.items?.find((line) => hasMarker(line, '_theme_upsell_key', key));
      if (existing) await this.#remove(existing);
      else if (item.dataset.variantAvailable !== 'false' && item.dataset.variantId) await this.#add(item);
      await this.#syncState();
    } catch (error) {
      if (error?.name !== 'AbortError') console.warn('[cart-upsells] Unable to update upsell:', error);
    } finally {
      item.dataset.busy = 'false';
      button.disabled = false;
    }
  }

  async #syncState() {
    try {
      const cart = await getCart();
      this.querySelectorAll('[data-upsell-item]').forEach((item) => {
        const key = item.dataset.upsellKey || '';
        const line = cart.items?.find((cartItem) => hasMarker(cartItem, '_theme_upsell_key', key));
        item.dataset.inCart = line ? 'true' : 'false';
        const button = item.querySelector('[data-upsell-action]');
        if (button) button.textContent = line ? (this.dataset.removeLabel || '移除') : (this.dataset.addLabel || '添加');
      });
    } catch (error) {
      if (error?.name !== 'AbortError') console.warn('[cart-upsells] Unable to read cart:', error);
    }
  }

  async #add(item) {
    const ids = sectionIds();
    const key = item.dataset.upsellKey || '';
    const variantId = item.dataset.variantId || '';
    await mutateCart(this, {
      url: window.Theme?.routes?.cart_add_url || '/cart/add.js',
      body: {
        items: [{ id: Number(variantId), quantity: 1, properties: { _theme_upsell_key: key } }],
        sections: ids.join(','),
        sections_url: window.location.pathname,
      },
      action: 'add',
      lines: [{ merchandiseId: variantId, quantity: 1 }],
      source: 'cart-product-upsells',
    });
  }

  async #remove(line) {
    const ids = sectionIds();
    await mutateCart(this, {
      url: window.Theme?.routes?.cart_change_url || '/cart/change.js',
      body: { id: line.key, quantity: 0, sections: ids.join(','), sections_url: window.location.pathname },
      action: 'remove',
      lines: [{ id: line.key, quantity: 0 }],
      source: 'cart-product-upsells',
    });
  }
}

if (!customElements.get('cart-gift')) customElements.define('cart-gift', CartGift);
if (!customElements.get('cart-upsells')) customElements.define('cart-upsells', CartUpsells);
