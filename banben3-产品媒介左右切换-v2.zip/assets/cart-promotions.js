class CartCountdownTimer extends HTMLElement {
  connectedCallback() {
    if (this._timer) return;
    this.remaining = Math.max(0, Number(this.dataset.duration) || 0);
    this.render();
    if (this.dataset.autoPlay !== 'false' && this.remaining > 0) {
      this._timer = window.setInterval(() => {
        this.remaining = Math.max(0, this.remaining - 1);
        this.render();
        if (!this.remaining) this.disconnectTimer();
      }, 1000);
    }
  }

  disconnectedCallback() {
    this.disconnectTimer();
  }

  disconnectTimer() {
    if (this._timer) window.clearInterval(this._timer);
    this._timer = null;
  }

  render() {
    const minutes = Math.floor(this.remaining / 60).toString().padStart(2, '0');
    const seconds = (this.remaining % 60).toString().padStart(2, '0');
    this.textContent = `${minutes}:${seconds}`;
    this.setAttribute('aria-label', `${minutes} minutes ${seconds} seconds remaining`);
  }
}

class CartTermsCheckbox extends HTMLElement {
  connectedCallback() {
    this.addEventListener('click', this.toggle);
    this.updateCheckoutState();
    this._checkoutHandler = this.handleCheckout;
    document.addEventListener('click', this._checkoutHandler, true);
  }

  disconnectedCallback() {
    this.removeEventListener('click', this.toggle);
    document.removeEventListener('click', this._checkoutHandler, true);
  }

  toggle = (event) => {
    if (event.target.closest('a, button, input, select, textarea')) return;
    this.dataset.checked = this.dataset.checked === 'true' ? 'false' : 'true';
    this.updateCheckoutState();
    this.hideWarning();
  };

  updateCheckoutState() {
    if (this.dataset.disableButton !== 'true') return;
    const scope = this.closest('dialog') || document;
    scope.querySelectorAll('#checkout, button[name="checkout"], [data-checkout-button]').forEach((button) => {
      button.disabled = this.dataset.checked !== 'true';
      button.setAttribute('aria-disabled', button.disabled ? 'true' : 'false');
    });
  }

  handleCheckout = (event) => {
    const button = event.target.closest?.('#checkout, button[name="checkout"], [data-checkout-button]');
    if (!button || this.dataset.checked === 'true') return;
    const scope = this.closest('dialog') || document;
    if (!scope.contains(button)) return;
    event.preventDefault();
    event.stopPropagation();
    this.showWarning();
  };

  showWarning() {
    const text = this.dataset.warningText || 'Please agree to the terms & conditions.';
    const warning = this.closest('div')?.querySelector('.tnc-checkbox-warning') || this.parentElement?.querySelector('.tnc-checkbox-warning');
    if (warning && this.dataset.warningPosition === 'under-checkbox') {
      warning.textContent = text;
      warning.classList.remove('hidden');
      return;
    }
    const scope = this.closest('dialog') || document;
    const checkout = scope.querySelector('#checkout, button[name="checkout"], [data-checkout-button]');
    if (!checkout) return;
    let target = scope.querySelector(`[data-tnc-warning="${this.id}"]`);
    if (!target) {
      target = document.createElement('p');
      target.dataset.tncWarning = this.id;
      target.className = 'tnc-checkbox-warning';
      checkout.parentElement?.appendChild(target);
    }
    target.textContent = text;
    target.classList.remove('hidden');
  }

  hideWarning() {
    this.closest('div')?.querySelector('.tnc-checkbox-warning')?.classList.add('hidden');
    const scope = this.closest('dialog') || document;
    scope.querySelector(`[data-tnc-warning="${this.id}"]`)?.classList.add('hidden');
  }
}

if (!customElements.get('countdown-timer')) customElements.define('countdown-timer', CartCountdownTimer);
if (!customElements.get('tnc-chekcbox')) customElements.define('tnc-chekcbox', CartTermsCheckbox);
