import { StandardEvents } from '@shopify/events';

class ProductSubscription extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;
    this.dataset.runtimeBound = 'true';
    this.section = this.closest('.shopify-section, dialog');
    this.onProductSelect = this.handleProductSelect.bind(this);
    this.onClick = this.handleClick.bind(this);
    this.onChange = this.handleChange.bind(this);
    this.section?.addEventListener(StandardEvents.productSelect, this.onProductSelect);
    this.addEventListener('click', this.onClick);
    this.addEventListener('change', this.onChange);
    this.selectMode(this.getSelectedMode(), false);
  }

  disconnectedCallback() {
    this.section?.removeEventListener(StandardEvents.productSelect, this.onProductSelect);
    this.removeEventListener('click', this.onClick);
    this.removeEventListener('change', this.onChange);
  }

  getSelectedMode() {
    const checked = this.querySelector('[data-subscription-mode]:checked');
    return checked?.value || this.querySelector('[data-subscription-box][data-selected="true"]')?.dataset.type || this.dataset.defaultMode || 'one_time';
  }

  handleClick(event) {
    const target = event.target instanceof Element ? event.target.closest('[data-subscription-mode]') : null;
    if (!(target instanceof HTMLInputElement)) return;
    this.selectMode(target.value);
  }

  handleChange(event) {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement || target instanceof HTMLInputElement)) return;
    if (target.matches('[data-selling-plan-selector], input[data-selling-plan-id]')) this.updateSellingPlan();
    if (target.matches('[data-subscription-mode]')) this.selectMode(target.value);
  }

  selectMode(mode, dispatchEvent = true) {
    const boxes = Array.from(this.querySelectorAll('[data-subscription-box]'));
    const selectedBox = boxes.find((box) => box.dataset.type === mode) || boxes[0];
    if (!selectedBox) return;
    const selectedMode = selectedBox.dataset.type || 'one_time';
    boxes.forEach((box) => {
      const active = box === selectedBox;
      box.dataset.selected = String(active);
      box.classList.toggle('subscription-widget__box--selected', active);
      const input = box.querySelector('[data-subscription-mode]');
      if (input instanceof HTMLInputElement) input.checked = active;
    });

    const hiddenInput = this.querySelector('[data-selling-plan-input]');
    if (hiddenInput instanceof HTMLInputElement) {
      if (selectedMode === 'subscription') {
        hiddenInput.disabled = false;
        this.updateSellingPlan(false);
      } else {
        hiddenInput.value = '';
        hiddenInput.disabled = true;
      }
    }
    this.dataset.selectedType = selectedMode;
    if (dispatchEvent) this.dispatchEvent(new CustomEvent('selling-plan:change', { bubbles: true, detail: { sellingPlanId: hiddenInput?.value || '', subscription: selectedMode === 'subscription' } }));
  }

  updateSellingPlan(dispatchEvent = true) {
    const selector = this.querySelector('[data-selling-plan-selector]');
    const radio = this.querySelector('input[data-selling-plan-id]:checked');
    const selected = selector instanceof HTMLSelectElement ? selector.selectedOptions[0] : radio;
    const hiddenInput = this.querySelector('[data-selling-plan-input]');
    if (!(hiddenInput instanceof HTMLInputElement) || hiddenInput.disabled) return;
    hiddenInput.value = selected?.dataset.sellingPlanId || selected?.value || this.dataset.firstSellingPlanId || '';
    this.renderPlanPrice(selected);
    if (dispatchEvent) this.dispatchEvent(new CustomEvent('selling-plan:change', { bubbles: true, detail: { sellingPlanId: hiddenInput.value, subscription: true } }));
  }

  renderPlanPrice(control) {
    if (!(control instanceof HTMLElement)) return;
    const price = Number(control.dataset.price || 0);
    const comparePrice = Number(control.dataset.comparePrice || price);
    const formatMoney = (cents) => {
      if (window.Shopify?.formatMoney) return window.Shopify.formatMoney(cents, this.dataset.moneyFormat);
      const value = (cents / 100).toFixed(2);
      return (this.dataset.moneyFormat || '${{amount}}').replace(/\{\{\s*amount(?:_no_decimals|_with_comma_separator|_with_apostrophe_separator)?\s*\}\}/, value);
    };
    this.querySelectorAll('[data-subscription-price]').forEach((node) => {
      const template = node.dataset.priceTemplate || '[price]';
      node.textContent = template.replaceAll('[price]', formatMoney(price)).replaceAll('[compare_price]', formatMoney(comparePrice));
    });
    this.querySelectorAll('[data-subscription-compare]').forEach((node) => {
      const template = node.dataset.compareTemplate || '[compare_price]';
      node.textContent = template.replaceAll('[price]', formatMoney(price)).replaceAll('[compare_price]', formatMoney(comparePrice));
      node.toggleAttribute('hidden', comparePrice <= price);
    });
  }

  handleProductSelect(event) {
    if (!event.promise) return;
    const previousMode = this.dataset.selectedType || this.getSelectedMode();
    const previousPlan = this.querySelector('[data-selling-plan-input]')?.value || '';
    event.promise.then(({ detail }) => {
      if (!detail?.html) return;
      if (detail.productId && String(detail.productId) !== String(this.dataset.productId)) return;
      const source = Array.from(detail.html.querySelectorAll('theme-subscription-widget')).find((node) => node.dataset.blockId === this.dataset.blockId);
      if (!source) {
        this.hidden = true;
        return;
      }
      this.hidden = false;
      this.dataset.productId = source.dataset.productId || this.dataset.productId;
      this.dataset.firstSellingPlanId = source.dataset.firstSellingPlanId || '';
      this.dataset.defaultMode = source.dataset.defaultMode || this.dataset.defaultMode;
      this.replaceChildren(...Array.from(source.childNodes).map((node) => node.cloneNode(true)));
      const planControl = Array.from(this.querySelectorAll('[data-selling-plan-id]')).find((node) => node.value === previousPlan || node.dataset.sellingPlanId === previousPlan);
      if (planControl instanceof HTMLInputElement) planControl.checked = true;
      if (planControl instanceof HTMLOptionElement) planControl.selected = true;
      this.selectMode(previousMode, false);
    }).catch((error) => {
      if (error?.name !== 'AbortError') console.warn('[product-subscription] Product update failed:', error);
    });
  }
}

if (!customElements.get('theme-subscription-widget')) {
  customElements.define('theme-subscription-widget', ProductSubscription);
}

