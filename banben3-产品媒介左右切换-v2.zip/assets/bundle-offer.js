import { CartErrorEvent, CartLinesUpdateEvent, StandardEvents } from '@shopify/events';

/**
 * Adds a configured product bundle through Shopify's cart/add endpoint while
 * keeping the official cart section update and drawer open flow.
 */
class BundleOffer extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;

    this.dataset.runtimeBound = 'true';
    this.abortController = new AbortController();
    this.form = this.querySelector('[data-bundle-form]');
    this.submitButton = this.querySelector('[data-bundle-submit]');
    this.spinner = this.querySelector('[data-bundle-spinner]');
    this.errorNode = this.querySelector('[data-bundle-error]');
    this.section = this.closest('.shopify-section, dialog');
    this.mainItem = this.querySelector('[data-bundle-item][data-main-item="true"]');

    const { signal } = this.abortController;
    this.addEventListener('change', this.#handleChange, { signal });
    this.form?.addEventListener('submit', this.#handleSubmit, { signal });
    this.section?.addEventListener(StandardEvents.productSelect, this.#handleProductSelect, { signal });
    this.#refresh();
  }

  disconnectedCallback() {
    this.abortController?.abort();
    this.abortController = null;
    delete this.dataset.runtimeBound;
  }

  #handleChange = (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;

    const variantSelect = target.closest('[data-bundle-variant]');
    if (variantSelect instanceof HTMLSelectElement) {
      this.#syncVariant(variantSelect);
    }

    if (target.matches('[data-bundle-select]')) {
      this.#refresh();
    }
  };

  #handleProductSelect = (event) => {
    if (!(event.target instanceof Element) || event.target.closest('product-card')) return;

    event.promise
      ?.then(({ detail }) => {
        const variant = detail?.resource;
        if (!this.mainItem) return;

        if (!variant?.id) {
          this.mainItem.dataset.variantId = '';
          this.mainItem.dataset.variantAvailable = 'false';
          this.#refresh();
          return;
        }

        this.mainItem.dataset.variantId = String(variant.id);
        this.mainItem.dataset.variantAvailable = String(variant.available !== false);
        this.mainItem.dataset.price = String(Number(variant.price) || 0);
        this.mainItem.dataset.comparePrice = String(
          Math.max(Number(variant.compare_at_price) || 0, Number(variant.price) || 0)
        );
        this.#refresh();
      })
      .catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[bundle-offer] Variant update failed:', error);
      });
  };

  #syncVariant(select) {
    const item = select.closest('[data-bundle-item]');
    const option = select.options[select.selectedIndex];
    if (!(item instanceof HTMLElement) || !option) return;

    const available = option.dataset.available !== 'false';
    item.dataset.variantId = option.dataset.variantId || option.value || '';
    item.dataset.price = option.dataset.price || '0';
    item.dataset.comparePrice = option.dataset.comparePrice || item.dataset.price;
    item.dataset.variantAvailable = String(available);

    const checkbox = item.querySelector('[data-bundle-select]');
    if (checkbox instanceof HTMLInputElement) {
      checkbox.disabled = !available;
      if (!available) checkbox.checked = false;
    }

    this.#refresh();
  }

  #refresh() {
    const selectedItems = this.#getSelectedItems();
    const total = selectedItems.reduce((sum, item) => sum + item.price, 0);
    const compare = selectedItems.reduce((sum, item) => sum + item.comparePrice, 0);

    this.querySelectorAll('[data-bundle-item]').forEach((item) => {
      const checkbox = item.querySelector('[data-bundle-select]');
      const selected = item.dataset.mainItem === 'true' || (checkbox instanceof HTMLInputElement && checkbox.checked);
      item.dataset.selected = String(selected);

      const priceNode = item.querySelector('[data-bundle-price]');
      if (priceNode) priceNode.textContent = this.#formatMoney(Number(item.dataset.price) || 0);
    });

    const totalNode = this.querySelector('[data-bundle-total]');
    const compareNode = this.querySelector('[data-bundle-total-compare]');
    if (totalNode) totalNode.textContent = this.#formatMoney(total);
    if (compareNode) {
      compareNode.textContent = compare > total ? this.#formatMoney(compare) : '';
      compareNode.hidden = compare <= total;
    }

    if (this.submitButton) {
      const mainRequired = this.dataset.includeMainProduct !== 'false';
      const mainAvailable = this.mainItem?.dataset.variantAvailable !== 'false';
      this.submitButton.disabled = selectedItems.length === 0 || (mainRequired && !mainAvailable);
    }
  }

  #getSelectedItems() {
    const includeMain = this.dataset.includeMainProduct !== 'false';
    return Array.from(this.querySelectorAll('[data-bundle-item]'))
      .filter((item) => {
        const checkbox = item.querySelector('[data-bundle-select]');
        return (item.dataset.mainItem === 'true' && includeMain)
          || (item.dataset.mainItem !== 'true' && checkbox instanceof HTMLInputElement && checkbox.checked);
      })
      .filter((item) => item.dataset.variantId && item.dataset.variantAvailable !== 'false')
      .map((item) => ({
        id: String(item.dataset.variantId),
        quantity: item.dataset.mainItem === 'true' ? this.#getMainQuantity() : 1,
        price: Number(item.dataset.price) || 0,
        comparePrice: Math.max(Number(item.dataset.comparePrice) || 0, Number(item.dataset.price) || 0),
        main: item.dataset.mainItem === 'true',
      }));
  }

  #getMainQuantity() {
    const productForm = this.#getProductForm();
    const quantityInput = productForm?.querySelector('[name="quantity"]');
    const quantity = Number(quantityInput?.value);
    return Number.isFinite(quantity) && quantity > 0 ? Math.floor(quantity) : 1;
  }

  #getProductForm() {
    const formId = this.dataset.productFormId;
    if (formId) {
      const form = document.getElementById(formId);
      if (form instanceof HTMLFormElement) return form;
    }

    const form = this.section?.querySelector('form[data-type="add-to-cart-form"]');
    return form instanceof HTMLFormElement ? form : null;
  }

  #buildPayload() {
    const selectedItems = this.#getSelectedItems();
    const includeMain = this.dataset.includeMainProduct !== 'false';
    const mainItem = selectedItems.find((item) => item.main);
    const items = [];
    const bundleProperties = { _theme_bundle_key: this.dataset.bundleKey || '' };
    const productForm = this.#getProductForm();

    if (productForm) {
      new FormData(productForm).forEach((value, name) => {
        const match = name.match(/^properties\[(.+)\]$/);
        if (match && value !== '') bundleProperties[match[1]] = String(value);
      });
    }

    if (includeMain && mainItem) {
      const main = {
        id: Number(mainItem.id),
        quantity: mainItem.quantity,
        properties: bundleProperties,
      };
      const sellingPlan = productForm?.querySelector('[name="selling_plan"]:not(:disabled)')?.value;
      if (sellingPlan) main.selling_plan = Number(sellingPlan);
      items.push(main);
    }

    let parentId = includeMain ? items[0]?.id || null : null;
    selectedItems
      .filter((item) => !item.main)
      .forEach((item, index) => {
        const line = {
          id: Number(item.id),
          quantity: item.quantity,
          properties: bundleProperties,
        };
        if (parentId && (includeMain || index > 0)) line.parent_id = parentId;
        items.push(line);
        if (!parentId) parentId = line.id;
      });

    return { items };
  }

  async #handleSubmit(event) {
    event.preventDefault();
    if (this.dataset.busy === 'true') return;

    const payload = this.#buildPayload();
    if (
      !payload.items.length
      || (this.dataset.includeMainProduct !== 'false'
        && (!this.mainItem?.dataset.variantId || this.mainItem?.dataset.variantAvailable === 'false'))
    ) {
      this.#setError('Please select at least one bundle item.');
      return;
    }

    const sectionIds = Array.from(document.querySelectorAll('cart-items-component[data-section-id]'))
      .map((component) => component.dataset.sectionId)
      .filter(Boolean);
    if (sectionIds.length) payload.sections = sectionIds.join(',');
    payload.sections_url = window.location.pathname;

    this.dataset.busy = 'true';
    this.#setError('');
    this.#setBusy(true);

    const deferred = CartLinesUpdateEvent.createPromise();
    const updateEvent = new CartLinesUpdateEvent({
      action: 'add',
      context: 'product',
      lines: payload.items.map((item) => ({ merchandiseId: String(item.id), quantity: item.quantity })),
      promise: deferred.promise,
    });
    document.dispatchEvent(updateEvent);

    try {
      const response = await fetch(this.dataset.cartAddUrl || '/cart/add.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: JSON.stringify(payload),
      });
      const result = await response.json();

      if (!response.ok || result.status) {
        throw new Error(result.description || result.message || 'Unable to add the bundle to cart.');
      }

      const cart = await this.#fetchCart();
      deferred.resolve({
        cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail: {
          items: cart.items,
          sections: result.sections,
          didError: false,
          source: 'bundle-offer',
          productId: this.dataset.productId,
        },
      });
    } catch (error) {
      deferred.resolve({ detail: { didError: true, source: 'bundle-offer' } });
      this.dispatchEvent(
        new CartErrorEvent({
          error: error?.message || 'Unable to add the bundle to cart.',
          code: 'INVALID',
        })
      );
      this.#setError(error?.message || 'Unable to add the bundle to cart.');
    } finally {
      this.dataset.busy = 'false';
      this.#setBusy(false);
    }
  }

  async #fetchCart() {
    const cartUrl = (this.dataset.cartUrl || '/cart').replace(/\/$/, '');
    const response = await fetch(`${cartUrl}.json`, {
      headers: { Accept: 'application/json' },
      credentials: 'same-origin',
    });
    if (!response.ok) throw new Error(`Unable to refresh cart (${response.status}).`);
    return response.json();
  }

  #setBusy(busy) {
    if (!this.submitButton) return;
    if (busy) this.submitButton.disabled = true;
    this.submitButton.setAttribute('aria-busy', String(busy));
    this.spinner?.classList.toggle('hidden', !busy);
    if (!busy) this.#refresh();
  }

  #setError(message) {
    if (!this.errorNode) return;
    this.errorNode.textContent = message;
    this.errorNode.classList.toggle('hidden', !message);
  }

  #formatMoney(cents) {
    if (window.Shopify?.formatMoney) {
      return window.Shopify.formatMoney(cents, this.dataset.moneyFormat);
    }

    const currency = window.Shopify?.currency?.active || 'USD';
    return new Intl.NumberFormat(document.documentElement.lang || undefined, {
      style: 'currency',
      currency,
    }).format(cents / 100);
  }
}

if (!customElements.get('bundle-offer')) {
  customElements.define('bundle-offer', BundleOffer);
}
