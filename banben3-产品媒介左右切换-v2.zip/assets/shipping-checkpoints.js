class ShippingCheckpoints extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;
    this.dataset.runtimeBound = 'true';

    const days = this.#parseLabels(this.dataset.dayLabels);
    const months = this.#parseLabels(this.dataset.monthLabels);
    const skippedDays = this.#parseSkippedDays(this.dataset.daysToSkip);
    const skippedDates = this.#parseSkippedDates(this.dataset.datesToSkip);
    const timezone = this.dataset.timezone || undefined;

    this.querySelectorAll('[data-dynamic-date="true"]').forEach((element) => {
      const min = this.#safeNumber(element.dataset.minDays);
      const max = Math.max(min, this.#safeNumber(element.dataset.maxDays, min));
      const template = element.dataset.text || element.textContent || '';
      const start = this.#format(this.#addDaysSkipping(min, skippedDays, skippedDates, timezone), days, months);
      const end = this.#format(this.#addDaysSkipping(max, skippedDays, skippedDates, timezone), days, months);
      element.innerHTML = template.replace(/\[start_date\]/g, start).replace(/\[end_date\]/g, end);
    });
  }

  disconnectedCallback() {
    delete this.dataset.runtimeBound;
  }

  #safeNumber(value, fallback = 0) {
    const number = Number(value);
    return Number.isFinite(number) && number >= 0 ? number : fallback;
  }

  #parseLabels(value) {
    return String(value || '').split(',').map((part) => part.trim()).filter(Boolean);
  }

  #parseSkippedDays(value) {
    const aliases = {
      sun: 0, sunday: 0, '周日': 0, '星期日': 0, '星期天': 0,
      mon: 1, monday: 1, '周一': 1, '星期一': 1,
      tue: 2, tues: 2, tuesday: 2, '周二': 2, '星期二': 2,
      wed: 3, wednesday: 3, '周三': 3, '星期三': 3,
      thu: 4, thur: 4, thurs: 4, thursday: 4, '周四': 4, '星期四': 4,
      fri: 5, friday: 5, '周五': 5, '星期五': 5,
      sat: 6, saturday: 6, '周六': 6, '星期六': 6,
    };
    return new Set(String(value || '').split(',').map((part) => {
      const normalized = part.trim().toLocaleLowerCase();
      if (/^[0-6]$/.test(normalized)) return Number(normalized);
      return aliases[normalized];
    }).filter((day) => day !== undefined));
  }

  #parseSkippedDates(value) {
    return String(value || '').split(',').map((part) => part.trim()).filter(Boolean).map((part) => {
      const match = part.match(/^(?:(\d{4})[-/.])?(\d{1,2})[-/.](\d{1,2})$/);
      if (!match) return null;
      const month = Number(match[2]);
      const day = Number(match[3]);
      if (month < 1 || month > 12 || day < 1 || day > 31) return null;
      return { year: Number(match[1]) || null, month, day };
    }).filter(Boolean);
  }

  #today(timezone) {
    const now = new Date();
    if (!timezone) {
      now.setHours(12, 0, 0, 0);
      return now;
    }
    try {
      const parts = new Intl.DateTimeFormat('en-CA', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
      const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
      return new Date(Date.UTC(Number(values.year), Number(values.month) - 1, Number(values.day), 12));
    } catch {
      now.setHours(12, 0, 0, 0);
      return now;
    }
  }

  #isSkipped(date, skippedDays, skippedDates) {
    if (skippedDays.has(date.getUTCDay())) return true;
    return skippedDates.some((item) => (
      (!item.year || item.year === date.getUTCFullYear())
      && item.month === date.getUTCMonth() + 1
      && item.day === date.getUTCDate()
    ));
  }

  #addDaysSkipping(amount, skippedDays, skippedDates, timezone) {
    const date = this.#today(timezone);
    let remaining = Math.max(0, Math.floor(amount));
    while (this.#isSkipped(date, skippedDays, skippedDates) || remaining > 0) {
      date.setUTCDate(date.getUTCDate() + 1);
      if (!this.#isSkipped(date, skippedDays, skippedDates) && remaining > 0) remaining -= 1;
    }
    return date;
  }

  #format(date, days, months) {
    const format = this.dataset.dateFormat || 'mm_dd';
    const day = days[date.getUTCDay()] || date.toLocaleDateString(document.documentElement.lang || 'en', { weekday: 'short', timeZone: 'UTC' });
    const month = months[date.getUTCMonth()] || date.toLocaleDateString(document.documentElement.lang || 'en', { month: 'short', timeZone: 'UTC' });
    const dayNumber = date.getUTCDate();
    const monthNumber = String(date.getUTCMonth() + 1).padStart(2, '0');
    const dayNumberPadded = String(dayNumber).padStart(2, '0');
    if (format === 'day_mm_dd') return `${month} ${dayNumber} ${day}`;
    if (format === 'day_dd_mm') return `${day}, ${dayNumber} ${month}`;
    if (format === 'dd_mm' || format === 'dd_mm_no_dot') return `${dayNumber} ${month}`;
    if (format === 'day_dd_mm_numeric') return `${day} ${dayNumberPadded}/${monthNumber}`;
    if (format === 'dd_mm_numeric') return `${dayNumberPadded}/${monthNumber}`;
    return `${month} ${dayNumber}`;
  }
}

if (!customElements.get('shipping-checkpoints')) {
  customElements.define('shipping-checkpoints', ShippingCheckpoints);
}
