import { CartLinesUpdateEvent, CartErrorEvent } from '@shopify/events';

/**
 * Product-page manual upsells. The cards only keep selection state; the
 * official product-form component adds selected cards together with the main
 * product so the normal cart section refresh remains in charge.
 */
class ProductInfoUpsell extends HTMLElement {
  connectedCallback() {
    const script = this.querySelector('[data-upsell-variants]');
    try {
      this.variants = script ? JSON.parse(script.textContent || '[]') : [];
    } catch (error) {
      this.variants = [];
      console.warn('[product-info-upsell] Invalid variant data', error);
    }

    this.querySelectorAll('[data-upsell-option]').forEach((select) => {
      select.addEventListener('change', () => this.updateVariant());
    });
    this.updateVariant();
  }

  get selected() {
    return this.dataset.selected === 'true';
  }

  setSelected(selected) {
    this.dataset.selected = selected ? 'true' : 'false';
    this.classList.toggle('product-info-upsell--selected', selected);
    const toggle = this.querySelector('[data-upsell-toggle]');
    toggle?.setAttribute('aria-pressed', selected ? 'true' : 'false');
  }

  updateVariant() {
    if (!this.variants?.length) return;
    const selects = [...this.querySelectorAll('[data-upsell-option]')];
    const values = selects.map((select) => select.value);
    let variant = this.variants.find((candidate) =>
      values.every((value, index) => !value || candidate[`option${index + 1}`] === value)
    );
    if (!variant) variant = this.variants.find((candidate) => candidate.available) || this.variants[0];

    this.dataset.id = String(variant.id || '');
    this.dataset.variantAvailable = variant.available ? 'true' : 'false';
    this.querySelectorAll('[data-upsell-price]').forEach((node) => {
      node.textContent = this.formatMoney(variant.price);
    });

    const comparePrice = Number(variant.compare_at_price || 0);
    this.querySelectorAll('[data-upsell-compare]').forEach((node) => {
      const hideComparePrice = this.closest('product-info-upsells')?.dataset.hideComparePrice === 'true';
      const shouldShow = comparePrice > Number(variant.price || 0) && !hideComparePrice;
      node.hidden = !shouldShow;
      node.textContent = shouldShow ? this.formatMoney(comparePrice) : '';
    });
    this.querySelector('[data-upsell-add]')?.toggleAttribute('disabled', !variant.available);
  }

  formatMoney(cents) {
    const format = this.closest('product-info-upsells')?.dataset.moneyFormat || '{{amount}}';
    if (window.Shopify?.formatMoney) return window.Shopify.formatMoney(cents, format);
    return new Intl.NumberFormat(document.documentElement.lang || undefined, {
      style: 'currency',
      currency: window.Shopify?.currency?.active || 'USD',
    }).format(Number(cents || 0) / 100);
  }
}

class ProductInfoUpsells extends HTMLElement {
  connectedCallback() {
    this.addEventListener('click', this.handleClick);
    this.addEventListener('change', this.handleChange);
  }

  disconnectedCallback() {
    this.removeEventListener('click', this.handleClick);
    this.removeEventListener('change', this.handleChange);
  }

  handleClick = (event) => {
    const toggle = event.target.closest('[data-upsell-toggle]');
    if (toggle) {
      event.preventDefault();
      toggle.closest('product-info-upsell')?.setSelected(!toggle.closest('product-info-upsell').selected);
      return;
    }

    const card = event.target.closest('product-info-upsell');
    if (card && this.dataset.toggleElement === 'container' && !event.target.closest('a, select, button, input')) {
      card.setSelected(!card.selected);
      return;
    }

    const addButton = event.target.closest('[data-upsell-add]');
    if (addButton) {
      event.preventDefault();
      const card = addButton.closest('product-info-upsell');
      if (card && !addButton.disabled) this.addSingleItem(card, addButton);
    }
  };

  handleChange = (event) => {
    if (event.target.matches('[data-upsell-option]')) {
      event.target.closest('product-info-upsell')?.updateVariant();
    }
  };

  async addSingleItem(card, button) {
    const variantId = card.dataset.id;
    if (!variantId) return;
    const originalText = button.textContent;
    button.disabled = true;
    button.setAttribute('aria-busy', 'true');
    const deferredEventPromise = CartLinesUpdateEvent.createPromise();
    this.dispatchEvent(new CartLinesUpdateEvent({
      action: 'add',
      context: 'product-upsell',
      lines: [{ merchandiseId: variantId, quantity: 1 }],
      promise: deferredEventPromise.promise,
    }));

    try {
      const response = await fetch(this.dataset.cartAddUrl || Theme.routes.cart_add_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          items: [{
            id: Number(variantId),
            quantity: 1,
            properties: { _theme_upsell_key: card.dataset.upsellKey || '' },
          }],
        }),
      });
      const result = await response.json();
      if (!response.ok || result.status) throw new Error(result.description || result.message || 'Add to cart failed');
      const cartComponent = document.querySelector('cart-items-component');
      const cart = cartComponent?.fetchCartData ? await cartComponent.fetchCartData() : await fetch(`${Theme.routes.cart_url}.js`).then((res) => res.json());
      deferredEventPromise.resolve({
        cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail: { items: cart.items, source: 'product-info-upsell', sourceId: this.id || 'product-info-upsells', itemCount: 1 },
      });
      button.textContent = button.dataset.addedLabel || 'Added';
    } catch (error) {
      deferredEventPromise.reject(error);
      this.dispatchEvent(new CartErrorEvent({ error: error.message, code: 'INVALID', detail: { source: 'product-info-upsell' } }));
      console.error('[product-info-upsell] Unable to add item', error);
    } finally {
      button.disabled = false;
      button.removeAttribute('aria-busy');
      if (button.textContent !== originalText) setTimeout(() => { button.textContent = originalText; }, 2000);
    }
  }
}

if (!customElements.get('product-info-upsell')) customElements.define('product-info-upsell', ProductInfoUpsell);
if (!customElements.get('product-info-upsells')) customElements.define('product-info-upsells', ProductInfoUpsells);
