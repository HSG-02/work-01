import { CartErrorEvent, CartLinesUpdateEvent, StandardEvents } from '@shopify/events';

const ADDITIONAL_KEY = '_theme_additional_key';
const PARENT_PRODUCT_KEY = '_theme_parent_product_id';
const MIN_QUANTITY_KEY = '_theme_min_parent_quantity';
const KIND_KEY = '_theme_additional_kind';
const KIND = 'quantity-gift';

function route(name, fallback) {
  return window.Theme?.routes?.[name] || window.routes?.[name] || fallback;
}

function sectionIds() {
  const ids = new Set();
  document.querySelectorAll('cart-items-component[data-section-id]').forEach((component) => {
    if (component.dataset.sectionId) ids.add(component.dataset.sectionId);
  });
  return [...ids];
}

function lineProperty(item, key) {
  return String(item?.properties?.[key] || '');
}

function isDecorative(item) {
  return Boolean(
    lineProperty(item, '_theme_upsell_key')
    || lineProperty(item, '_theme_gift_key')
    || lineProperty(item, ADDITIONAL_KEY)
  );
}

async function fetchCart() {
  const response = await fetch(`${route('cart_url', '/cart').replace(/\/$/, '')}.js`, {
    headers: { Accept: 'application/json' },
    credentials: 'same-origin',
  });
  if (!response.ok) throw new Error(`Unable to refresh cart (${response.status}).`);
  return response.json();
}

async function mutateCart({ url, body, action, lines, source }) {
  const promise = CartLinesUpdateEvent.createPromise();
  document.dispatchEvent(new CartLinesUpdateEvent({
    action,
    context: 'cart',
    lines,
    promise: promise.promise,
  }));

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
      },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok || result.status || result.errors) {
      throw new Error(result.description || result.message || result.errors || '购物车更新失败。');
    }

    const cart = Array.isArray(result.items) ? result : await fetchCart();
    promise.resolve({
      cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
      detail: {
        items: cart.items,
        sections: result.sections,
        didError: false,
        source,
      },
    });
    return cart;
  } catch (error) {
    promise.resolve({ detail: { didError: true, source } });
    document.dispatchEvent(new CartErrorEvent({
      error: error?.message || '购物车更新失败。',
      code: 'INVALID',
    }));
    throw error;
  }
}

class ProductQuantityGifts extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;
    this.dataset.runtimeBound = 'true';
    this.abortController = new AbortController();
    this.syncing = false;
    const { signal } = this.abortController;

    this.quantityScope = this.closest('.product-information') || document;
    this.quantityScope.addEventListener('input', this.#onQuantityInput, { signal });
    this.quantityScope.addEventListener('change', this.#onQuantityInput, { signal });
    document.addEventListener(StandardEvents.cartLinesUpdate, this.#onCartUpdate, { signal });
    this.#updateVisualState(this.#currentQuantity());
    if (this.dataset.designMode !== 'true') this.#syncCart();
  }

  disconnectedCallback() {
    this.abortController?.abort();
    this.abortController = null;
    delete this.dataset.runtimeBound;
  }

  #onQuantityInput = () => {
    this.#updateVisualState(this.#currentQuantity());
  };

  #onCartUpdate = (event) => {
    event.promise?.then((payload) => {
      const detail = payload?.detail || {};
      if (detail.source === 'product-quantity-gifts' || detail.didError) return;

      // A product form add is the point at which quantity gifts can be added safely.
      // Other cart updates still reconcile the current cart so removing the parent
      // product also removes gifts that no longer qualify.
      const eventProductId = Number(detail.productId || 0);
      const mainProductId = Number(this.dataset.mainProductId || 0);
      if (eventProductId && mainProductId && eventProductId !== mainProductId && detail.source === 'product-form-component') return;
      this.#syncCart(payload?.cart).catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[quantity-gifts] Unable to sync gifts:', error);
      });
    }).catch((error) => {
      if (error?.name !== 'AbortError') console.warn('[quantity-gifts] Cart event failed:', error);
    });
  };

  #currentQuantity() {
    const input = this.quantityScope?.querySelector?.(
      'product-form-component input[name="quantity"], input[name="quantity"]'
    );
    return Math.max(1, Number(input?.value || this.dataset.defaultQuantity || 1) || 1);
  }

  #cards() {
    return [...this.querySelectorAll('[data-quantity-gift][data-gift-key][data-variant-id]')];
  }

  #updateVisualState(quantity) {
    const amount = Math.max(0, Number(quantity) || 0);
    this.#cards().forEach((card) => {
      const unlocked = amount >= Number(card.dataset.requiredQuantity || 1);
      card.dataset.unlocked = String(unlocked);
      card.classList.toggle('quantity-gift--unlocked', unlocked);
      card.classList.toggle('quantity-gift--locked', !unlocked);
      card.setAttribute('aria-disabled', String(!unlocked));
    });
    this.dispatchEvent(new CustomEvent('quantity-gifts:change', {
      bubbles: true,
      detail: { quantity: amount },
    }));
  }

  async #syncCart(initialCart = null) {
    if (this.syncing || this.dataset.designMode === 'true') return;
    this.syncing = true;
    this.dataset.syncing = 'true';
    try {
      let cart = initialCart?.items ? initialCart : await fetchCart();
      const mainProductId = Number(this.dataset.mainProductId || 0);
      if (!mainProductId) return;

      const primaryItems = (cart.items || []).filter((item) => (
        Number(item.product_id) === mainProductId && !isDecorative(item)
      ));
      const mainQuantity = primaryItems.reduce((total, item) => total + Number(item.quantity || 0), 0);
      this.#updateVisualState(mainQuantity || this.#currentQuantity());

      const cards = this.#cards();
      const giftLines = (cart.items || []).filter((item) => (
        lineProperty(item, KIND_KEY) === KIND
        && lineProperty(item, PARENT_PRODUCT_KEY) === String(mainProductId)
      ));

      // Remove expired gifts or a line left behind after a gift variant changed.
      for (const line of giftLines) {
        const card = cards.find((candidate) => candidate.dataset.giftKey === lineProperty(line, ADDITIONAL_KEY));
        const qualifies = card && mainQuantity >= Number(card.dataset.requiredQuantity || lineProperty(line, MIN_QUANTITY_KEY) || 1);
        const variantMatches = card && String(card.dataset.variantId) === String(line.variant_id);
        if (!qualifies || !variantMatches) {
          cart = await this.#remove(line);
        } else if (Number(line.quantity || 0) !== 1) {
          cart = await this.#change(line, 1);
        }
      }

      // Add each newly qualified gift once. The parent product is already in the
      // cart when this runs, so the gift never exists without its qualifying line.
      if (mainQuantity > 0) {
        for (const card of cards) {
          if (mainQuantity < Number(card.dataset.requiredQuantity || 1)) continue;
          const key = card.dataset.giftKey;
          const present = (cart.items || []).some((line) => (
            lineProperty(line, KIND_KEY) === KIND
            && lineProperty(line, PARENT_PRODUCT_KEY) === String(mainProductId)
            && lineProperty(line, ADDITIONAL_KEY) === key
            && String(line.variant_id) === String(card.dataset.variantId)
          ));
          if (!present) cart = await this.#add(card);
        }
      }
    } finally {
      this.syncing = false;
      this.dataset.syncing = 'false';
    }
  }

  async #add(card) {
    const variantId = String(card.dataset.variantId || '');
    const key = String(card.dataset.giftKey || '');
    const mainProductId = String(this.dataset.mainProductId || '');
    const sections = sectionIds();
    return mutateCart({
      url: route('cart_add_url', '/cart/add.js'),
      action: 'add',
      source: 'product-quantity-gifts',
      lines: [{ merchandiseId: variantId, quantity: 1 }],
      body: {
        items: [{
          id: Number(variantId),
          quantity: 1,
          properties: {
            [ADDITIONAL_KEY]: key,
            [PARENT_PRODUCT_KEY]: mainProductId,
            [MIN_QUANTITY_KEY]: String(card.dataset.requiredQuantity || 1),
            [KIND_KEY]: KIND,
          },
        }],
        sections: sections.join(','),
        sections_url: window.location.pathname,
      },
    });
  }

  async #remove(line) {
    const sections = sectionIds();
    return mutateCart({
      url: route('cart_change_url', '/cart/change.js'),
      action: 'remove',
      source: 'product-quantity-gifts',
      lines: [{ id: line.key, quantity: 0 }],
      body: { id: line.key, quantity: 0, sections: sections.join(','), sections_url: window.location.pathname },
    });
  }

  async #change(line, quantity) {
    const sections = sectionIds();
    return mutateCart({
      url: route('cart_change_url', '/cart/change.js'),
      action: 'change',
      source: 'product-quantity-gifts',
      lines: [{ id: line.key, quantity }],
      body: { id: line.key, quantity, sections: sections.join(','), sections_url: window.location.pathname },
    });
  }
}

if (!customElements.get('quantity-gifts')) customElements.define('quantity-gifts', ProductQuantityGifts);

class QuantityGiftCartCleanup extends HTMLElement {
  connectedCallback() {
    if (this.dataset.runtimeBound === 'true') return;
    this.dataset.runtimeBound = 'true';
    this.abortController = new AbortController();
    document.addEventListener(StandardEvents.cartLinesUpdate, this.#onCartUpdate, {
      signal: this.abortController.signal,
    });
    this.#sync();
  }

  disconnectedCallback() {
    this.abortController?.abort();
    this.abortController = null;
    delete this.dataset.runtimeBound;
  }

  #onCartUpdate = (event) => {
    event.promise?.then((payload) => {
      const source = payload?.detail?.source || '';
      if (source === 'product-quantity-gifts' || source === 'product-quantity-gift-cleanup') return;
      this.#sync(payload?.cart).catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[quantity-gifts] Unable to remove expired gifts:', error);
      });
    });
  };

  async #sync(initialCart = null) {
    if (this.dataset.syncing === 'true') return;
    this.dataset.syncing = 'true';
    try {
      let cart = initialCart?.items ? initialCart : await fetchCart();
      const quantities = new Map();
      (cart.items || []).filter((item) => !isDecorative(item)).forEach((item) => {
        const productId = String(item.product_id || '');
        quantities.set(productId, (quantities.get(productId) || 0) + Number(item.quantity || 0));
      });

      const gifts = (cart.items || []).filter((item) => lineProperty(item, KIND_KEY) === KIND);
      for (const gift of gifts) {
        const parentId = lineProperty(gift, PARENT_PRODUCT_KEY);
        const required = Math.max(1, Number(lineProperty(gift, MIN_QUANTITY_KEY)) || 1);
        if ((quantities.get(parentId) || 0) < required) cart = await mutateCart({
          url: route('cart_change_url', '/cart/change.js'),
          action: 'remove',
          source: 'product-quantity-gift-cleanup',
          lines: [{ id: gift.key, quantity: 0 }],
          body: {
            id: gift.key,
            quantity: 0,
            sections: sectionIds().join(','),
            sections_url: window.location.pathname,
          },
        });
      }
    } finally {
      this.dataset.syncing = 'false';
    }
  }
}

if (!customElements.get('quantity-gift-cart-cleanup')) {
  customElements.define('quantity-gift-cart-cleanup', QuantityGiftCartCleanup);
}
